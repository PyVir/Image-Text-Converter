from PIL import Image
import time, sys, agpy.agpy_types as agpy_types, cv2, os

def loadmp4(video_name : str, limit : int = 0):
	try:
		if not os.path.exists('data'): os.makedirs('data')
	except OSError:
		print ('Error: Creating directory of data')

	cam = cv2.VideoCapture(video_name)
	currentframe = 0  
	fps = cam.get(cv2.CAP_PROP_FPS)
	while limit != 1:
		limit -= 1
		currentframe += 1
		ret,frame = cam.read()
		if ret == False: break
		name = './data/frame' + str(currentframe) + '.png'
		cv2.imwrite(name, frame)
	return fps

def loadimg(img_name : str, mode : str = "RGB"):
	return Image.open(img_name).convert(mode)

def imgtoarr(img : list):
	return [[img.getpixel((j, i)) for j in range(img.width)] for i in range(img.height)]

def pallete(length : int):
	return agpy_types.pallete(length)

def printarr(arr : list):
	final = ""
	for j in range(len(arr)):
		line = "\n"
		for i in range(len(arr[j])):
			line += arr[j][i] * 2
		final += line
	return final

def Ascii(img : list, pallete : agpy_types.pallete):
	data = imgtoarr(img)
	return [[pallete[round(((0.299 * data[j][i][0]) + (0.587 * data[j][i][1]) + (0.114 * data[j][i][2])) // pallete.cp)] for i in range(len(data[0]))] for j in range(len(data))]

if __name__ == "__main__":
	print("I think you're not supposed to be here. :( ")
	sys.exit(1)
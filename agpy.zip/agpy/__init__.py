from PIL import Image
import time, sys, agpy.agpy_types as agpy_types

def loadimg(img_name : str, mode : str = "RGB"):
	return Image.open(img_name).convert(mode)

def imgtoarr(img : list):
	return [[img.getpixel((j, i)) for j in range(img.width)] for i in range(img.height)]

def pallete(length : int):
	return agpy_types.pallete(length)

def printarr(arr : list):
	final = ""
	for j in range(len(arr)):
		line = "\n"
		for i in range(len(arr[j])):
			line += arr[j][i]
		final += line
	print(final)

def Ascii(img : list, pallete : agpy_types.pallete):
	data = imgtoarr(img)
	return [[pallete[sum(data[j][i]) // len(data[j][i]) // pallete.cp] for i in range(len(data[0]))] for j in range(len(data))]

if __name__ == "__main__":
	print("I think you're not supposed to be here. :( ")
	sys.exit(1)
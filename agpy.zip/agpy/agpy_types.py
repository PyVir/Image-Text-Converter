import sys

class pallete:
	def display(self):
		print(self.pallete)
		
	def set(self, other_pallete : list):
		if type(other_pallete) == type(list()):
			self.length = len(other_pallete)
			self.pallete = other_pallete
		elif type(other_pallete) == type(pallete(0)):
			self.length = other_pallete.length
			self.pallete = other_pallete.pallete
		self.update_cp()

	def clone(self):
		new = pallete(self.length)
		new.set(self)
		return new

	def reverse(self):
		self.pallete = [self.pallete[i] for i in range(self.length - 1, -1, -1)]

	def extend(self, new : list):
		self.length += len(new)
		for i in range(len(new)):
			self.pallete.append(new[i])
		self.update_cp()

	def append(self, element : object):
		self.length += 1
		self.pallete.append(element)
		self.update_cp()

	def update_cp(self):
		self.cp = 255 // (self.length - 1)
	
	def __getitem__(self, index : int):
		return self.pallete[index]

	def __setitem__(self, index : int, element : object):
		self.pallete[index] = element

	def __init__(self, length : int):
		self.length = length
		self.pallete = [""] * length
		self.update_cp()

if __name__ == "__main__":
	print("I think you're not supposed to be here. :( ")
	sys.exit(1)